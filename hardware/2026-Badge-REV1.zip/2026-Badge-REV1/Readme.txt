Width: 4910 mils
Height: 3845 mils
Layer Count: Two
Material: FR4
Thickness: .062”
Finish: ENIG Finished copper 1 oz.
Red Mask, White Silk screen